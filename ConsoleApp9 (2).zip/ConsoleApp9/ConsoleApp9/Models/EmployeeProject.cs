﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp9.Models
{  [PrimaryKey(nameof(EmployeeId), nameof(ProjectId))]
  
    public class EmployeeProject
    {
        [Key]
        public int EmployeeId { get; set; }
        [Key]
        public int ProjectId { get; set; }

        public string Role { get; set; } = null!;

        public virtual Employee Employee { get; set; } = null!;

        public virtual Project Project { get; set; } = null!;
    }
}
