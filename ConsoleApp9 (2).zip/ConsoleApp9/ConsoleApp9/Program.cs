﻿using ConsoleApp9.Models;

namespace ConsoleApp9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using var context = new SchoolContext();
            while (true)
            {
                Console.WriteLine("Choose an option:");
                Console.WriteLine("1  - Add Department");
                Console.WriteLine("2  - Add Project");
                Console.WriteLine("3  - Add Employee");
                Console.WriteLine("4  - View Departments");
                Console.WriteLine("5  - View Projects");
                Console.WriteLine("6  - View Employees");
                Console.WriteLine("7  - Delete Department");
                Console.WriteLine("8  - Delete Employee");
                Console.WriteLine("9  - Delete Project");
                Console.WriteLine("10 - Update Department");
                Console.WriteLine("11 - Update Employee");
                Console.WriteLine("12 - Update Project");
                
                
                var input = Console.ReadLine();
                Console.Clear();
                switch (input)
                {
                    case "1" :
                        Console.Write("Enter Department Name: ");
                        var dName = Console.ReadLine();
                        context.Departments.Add(new Department { Name = dName });
                        context.SaveChanges();
                        break;
                    case "2" :
                        Console.Write("Enter Project Name: ");
                        var pName = Console.ReadLine();
                        Console.Write("Enter Project start date (yyyy-MM-dd): ");
                        var startdate = DateOnly.Parse(Console.ReadLine());
                        Console.WriteLine("if you need to save end date project select 1 ");
                        int i = int.Parse(Console.ReadLine());
                        if (i == 1)
                        {
                            Console.Write("Enter Project end date (yyyy-MM-dd): ");
                            var endtdate = DateOnly.Parse(Console.ReadLine());
                            context.Projects.Add(new Project { Name = pName, StartDate = startdate, EndDate = endtdate });
                            context.SaveChanges();
                        }
                        else
                        {
                            context.Projects.Add(new Project { Name = pName, StartDate = startdate });
                            context.SaveChanges();
                            Console.WriteLine("project name saved without end date ");

                        }
                        break;
                    case "3" :
                        Console.Write("Enter Employee FName: ");
                        var efName = Console.ReadLine();
                        Console.Write("Enter Employee LName: ");
                        var elName = Console.ReadLine();
                        Console.WriteLine("Choose Department ID:");
                        foreach (var d in context.Departments)
                        Console.WriteLine($"{d.DepartmentId} - {d.Name}");
                        int depId = int.Parse(Console.ReadLine());
                        context.Employees.Add(new Employee { FirstName = efName, LastName = elName, DepartmentId = depId });
                        context.SaveChanges();
                        break;
                    case "4" :
                        Console.WriteLine(" ----------------------------");
                        Console.WriteLine("|{0,-15}| {1,-11}|", "DepartmentId", "DName");
                        Console.WriteLine("|---------------|------------|");
                        foreach (var dept in context.Departments)
                        {
                            Console.WriteLine("|     {0,-10}| {1,-11}|",
                            dept.DepartmentId, dept.Name);
                        }

                        Console.WriteLine(" ---------------|------------");

                        break;
                    case "5" :
                        Console.WriteLine(" ----------------------------------------------------------------------------");
                        Console.WriteLine("|{0,-10}| {1,-30}| {2,-15}| {3,-15}|", "ProjectId", "PName", "StartDate", "EndDate");
                        Console.WriteLine("|----------|-------------------------------|----------------|----------------|");
                        foreach (var proj in context.Projects)
                        {
                            Console.WriteLine("|     {0,-5}| {1,-30}| {2,-15}| {3,-15}|",
                                proj.ProjectId, proj.Name, proj.StartDate, proj.EndDate);
                        }
                        Console.WriteLine(" ----------|-------------------------------|----------------|----------------");
                        break;
                    case "6" :
                        Console.WriteLine(" --------------------------------------------");
                        Console.WriteLine("|{0,-10}|{1,-9}|{2,-8}|{3,-12}|", "EmployeeId", "FirstName", " LastName ", "DepartmentId");
                        Console.WriteLine("|----------|---------|----------|------------|");
                        var employees = context.Employees.ToList();
                        foreach (var emp in employees) 
                        { 
                            Console.WriteLine("|     {0,-5}| {1,-8}| {2,-9}|     {3,-7}|", emp.EmployeeId, emp.FirstName, emp.LastName, emp.DepartmentId);
                        }
                        Console.WriteLine(" ----------|---------|----------|------------");
                        break;
                    case "7" :
                        Console.WriteLine("Choose Department ID to delete:");
                        foreach (var d in context.Departments)
                            Console.WriteLine($"{d.DepartmentId} - {d.Name}");
                        if (!int.TryParse(Console.ReadLine(), out int delDepId) || !context.Departments.Any(d => d.DepartmentId == delDepId))
                        {
                            Console.WriteLine("Error: Invalid Department ID!");
                            break;
                        }
                        var department = context.Departments.Find(delDepId);
                        context.Departments.Remove(department);
                        context.SaveChanges();
                        Console.WriteLine("Department deleted successfully!");
                        break;
                    case "8" :
                        Console.WriteLine("Choose Employee ID to delete:");
                        foreach (var e in context.Employees)
                            Console.WriteLine($"{e.EmployeeId} - {e.FirstName} {e.LastName}");
                        if (!int.TryParse(Console.ReadLine(), out int delEmpId) || !context.Employees.Any(e => e.EmployeeId == delEmpId))
                        {
                            Console.WriteLine("Error: Invalid Employee ID!");
                            break;
                        }
                        var employee = context.Employees.Find(delEmpId);
                        var relatedEmpProjects = context.EmployeeProjects.Where(ep => ep.EmployeeId == delEmpId);
                        context.EmployeeProjects.RemoveRange(relatedEmpProjects);
                        context.Employees.Remove(employee);
                        context.SaveChanges();
                        Console.WriteLine("Employee and related assignments deleted successfully!");
                        break;
                    case "9" :
                        Console.WriteLine("Choose Project ID to delete:");
                        foreach (var p in context.Projects)
                            Console.WriteLine($"{p.ProjectId} - {p.Name}");
                        if (!int.TryParse(Console.ReadLine(), out int delProjId) || !context.Projects.Any(p => p.ProjectId == delProjId))
                        {
                            Console.WriteLine("Error: Invalid Project ID!");
                            break;
                        }
                        var project = context.Projects.Find(delProjId);
                        var relatedEmployeeProjects = context.EmployeeProjects.Where(ep => ep.ProjectId == delProjId);
                        context.EmployeeProjects.RemoveRange(relatedEmployeeProjects);
                        context.Projects.Remove(project);
                        context.SaveChanges();
                        Console.WriteLine("Project and related assignments deleted successfully!");
                        break;
                    case "10":
                        Console.WriteLine("Choose Department ID to update:");
                        foreach (var d in context.Departments)
                            Console.WriteLine($"{d.DepartmentId} - {d.Name}");
                        if (!int.TryParse(Console.ReadLine(), out int editDepId) || !context.Departments.Any(d => d.DepartmentId == editDepId))
                        {
                            Console.WriteLine("Error: Invalid Department ID!");
                            break;
                        }
                        Console.Write("Enter new Department Name: ");
                        var newDName = Console.ReadLine();
                        if (string.IsNullOrWhiteSpace(newDName))
                        {
                            Console.WriteLine("Error: Department name cannot be empty!");
                            break;
                        }
                        var deptToEdit = context.Departments.Find(editDepId);
                        deptToEdit.Name = newDName;
                        context.SaveChanges();
                        Console.WriteLine("Department updated successfully!");
                        break;
                    case "11":
                        Console.WriteLine("Choose Employee ID to update:");
                        foreach (var e in context.Employees)
                            Console.WriteLine($"{e.EmployeeId} - {e.FirstName} {e.LastName}");
                        if (!int.TryParse(Console.ReadLine(), out int editEmpId) || !context.Employees.Any(e => e.EmployeeId == editEmpId))
                        {
                            Console.WriteLine("Error: Invalid Employee ID!");
                            break;
                        }
                        Console.Write("Enter new First Name: ");
                        var newEFName = Console.ReadLine();
                        Console.Write("Enter new Last Name: ");
                        var newELName = Console.ReadLine();
                        if (string.IsNullOrWhiteSpace(newEFName) || string.IsNullOrWhiteSpace(newELName))
                        {
                            Console.WriteLine("Error: First and Last names cannot be empty!");
                            break;
                        }
                        Console.WriteLine("Choose new Department ID:");
                        foreach (var d in context.Departments)
                            Console.WriteLine($"{d.DepartmentId} - {d.Name}");
                        if (!int.TryParse(Console.ReadLine(), out int newDepId) || !context.Departments.Any(d => d.DepartmentId == newDepId))
                        {
                            Console.WriteLine("Error: Invalid Department ID!");
                            break;
                        }
                        var empToEdit = context.Employees.Find(editEmpId);
                        empToEdit.FirstName = newEFName;
                        empToEdit.LastName = newELName;
                        empToEdit.DepartmentId = newDepId;
                        context.SaveChanges();
                        Console.WriteLine("Employee updated successfully!");
                        break;
                    case "12":
                        Console.WriteLine("Choose Project ID to update:");
                        foreach (var p in context.Projects)
                            Console.WriteLine($"{p.ProjectId} - {p.Name}");
                        if (!int.TryParse(Console.ReadLine(), out int editProjId) || !context.Projects.Any(p => p.ProjectId == editProjId))
                        {
                            Console.WriteLine("Error: Invalid Project ID!");
                            break;
                        }
                        Console.Write("Enter new Project Name: ");
                        var newPName = Console.ReadLine();
                        if (string.IsNullOrWhiteSpace(newPName))
                        {
                            Console.WriteLine("Error: Project name cannot be empty!");
                            break;
                        }
                        Console.Write("Enter new Start Date (yyyy-MM-dd): ");
                        if (!DateOnly.TryParse(Console.ReadLine(), out var newStartDate))
                        {
                            Console.WriteLine("Error: Invalid date format!");
                            break;
                        }
                        Console.WriteLine("Enter 1 to update End Date, or any other key to keep it unchanged:");
                        DateOnly? newEndDate = null;
                        if (Console.ReadLine() == "1")
                        {
                            Console.Write("Enter new End Date (yyyy-MM-dd): ");
                            if (!DateOnly.TryParse(Console.ReadLine(), out var endDate))
                            {
                                Console.WriteLine("Error: Invalid date format!");
                                break;
                            }
                            newEndDate = endDate;
                        }
                        var projToEdit = context.Projects.Find(editProjId);
                        projToEdit.Name = newPName;
                        projToEdit.StartDate = newStartDate;
                        projToEdit.EndDate = newEndDate;
                        context.SaveChanges();
                        Console.WriteLine("Project updated successfully!");
                        break;
                    case "0" :
                        return;
                    default  :
                        Console.WriteLine("Invalid option");
                        break;
                }
                Console.WriteLine("\n\n\nPress Enter to continue...");
                Console.ReadLine();
                Console.Clear();
            }

        }
    }
}
