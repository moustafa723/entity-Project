﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ConsoleApp9.Models;

public partial class SchoolContext : DbContext
{
    public SchoolContext()
    {
    }

    public SchoolContext(DbContextOptions<SchoolContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Department> Departments { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<EmployeeProject> EmployeeProjects { get; set; }
    public virtual DbSet<Project> Projects { get; set; }    
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlite("data source= D:\\ConsoleApp9\\ConsoleApp9\\schoool.db");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<EmployeeProject>(entity =>
        {
          
            entity.HasKey(e => new { e.EmployeeId, e.ProjectId });

            OnModelCreatingPartial(modelBuilder);
        });
        
    }
    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
